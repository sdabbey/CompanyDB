USE companyDB
SELECT * FROM
Comp_grp1;